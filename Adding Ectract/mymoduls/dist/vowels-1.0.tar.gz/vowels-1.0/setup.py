from setuptools import setup
setup(name='vowels' , version='1.0', py_modules=['vowels'])